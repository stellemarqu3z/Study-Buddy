// GLOBAL STATE
let currentTasks = [];
let currentQuizData = [];
let userAnswers = {};
let quizTimerInterval = null;
let quizStartTime = null;
let currentGradeCalculation = null;

// INITIALIZATION
document.addEventListener('DOMContentLoaded', function() {
    updateDate();
    initializeApp();
});

async function initializeApp() {
    await loadTasks();
    await loadGrades();
    await loadDashboardStats();
    await loadSubjects();
}

function updateDate() {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const dateElement = document.getElementById("todayDate");
    if (dateElement) {
        dateElement.innerText = new Date().toLocaleDateString(undefined, options);
    }
}

function showSection(sectionId) {
    // navigation UI
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    const navItem = document.getElementById(`nav-${sectionId}`);
    if (navItem) navItem.classList.add('active');

    // Title
    const titles = {
        'dashboard': 'Dashboard Overview',
        'tasks': 'Task Management',
        'grades': 'Grade Tracker & Calculator',
        'quizzes': 'Interactive Quiz Studio'
    };
    const titleElement = document.getElementById("sectionTitle");
    if (titleElement) titleElement.innerText = titles[sectionId] || sectionId;

    // ANIMATION PART 
    const sections = document.querySelectorAll('.section');
    sections.forEach(sec => sec.classList.remove('active'));

    const target = document.getElementById(sectionId);
    setTimeout(() => {
        if (target) target.classList.add('active');
    }, 50);

    // BACK BUTTON LOGIC 
    const backBtn = document.querySelector('.topbar button');
    if (backBtn) {
        if (sectionId === 'dashboard') {
            backBtn.style.display = 'none';
        } else {
            backBtn.style.display = 'inline-block';
        }
    }

    // Refresh data if needed
    if(sectionId === 'dashboard') loadDashboardStats();
    if(sectionId === 'tasks') loadTasks();
    if(sectionId === 'grades') loadGrades();
}
// ---------------- UTILITY FUNCTIONS ---------------- //

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;margin-left:10px;">×</button>
    `;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function formatDate(dateString) {
    if (!dateString) return 'No date';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function isOverdue(dateString) {
    if (!dateString) return false;
    const due = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return due < today;
}

// ---------------- TASKS ---------------- //

async function handleAddTask() {
    const subjectInput = document.getElementById("taskSubject");
    const taskInput = document.getElementById("taskDesc");
    const deadlineInput = document.getElementById("taskDeadline");

    const subject = subjectInput.value.trim();
    const task = taskInput.value.trim();
    const deadline = deadlineInput.value;

    if (!subject || !task || !deadline) {
        showToast("Please fill in all fields.", "error");
        return;
    }

    try {
        const response = await fetch("/add_task", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({subject, task, deadline})
        });
        
        const data = await response.json();
        
        if(response.ok) {
            // Reset fields
            subjectInput.value = "";
            taskInput.value = "";
            deadlineInput.value = "";
            
            showToast("Task added successfully!");
            await loadTasks();
            await loadDashboardStats();
        } else {
            showToast(data.error || "Failed to add task", "error");
        }
    } catch (e) {
        console.error("Error adding task:", e);
        showToast("Error adding task. Please try again.", "error");
    }
}

async function loadTasks() {
    try {
        const response = await fetch("/get_tasks");
        if (!response.ok) throw new Error('Failed to fetch tasks');
        
        const tasks = await response.json();
        currentTasks = tasks;
        
        renderTaskTable(tasks);
        renderUpcomingTasks(tasks);
    } catch (e) {
        console.error("Error loading tasks:", e);
        showToast("Failed to load tasks", "error");
    }
}

function renderTaskTable(tasks) {
    const tbody = document.getElementById("taskTableBody");
    if (!tbody) return;
    
    tbody.innerHTML = "";

    if (tasks.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-secondary text-center">No tasks found. Add one above!</td></tr>';
        return;
    }

    tasks.forEach(t => {
        const overdue = isOverdue(t.deadline);
        const tr = document.createElement("tr");
        if (overdue) tr.classList.add('overdue');
        
        tr.innerHTML = `
            <td class="font-bold">${escapeHtml(t.subject)}</td>
            <td>${escapeHtml(t.task)}</td>
            <td class="${overdue ? 'text-danger' : ''}">${formatDate(t.deadline)} ${overdue ? '(Overdue)' : ''}</td>
            <td><span class="badge ${overdue ? 'badge-danger' : 'badge-success'}">${overdue ? 'Overdue' : 'Pending'}</span></td>
            <td>
    <button class="btn btn-sm btn-secondary" onclick="editTask(${t.id})">Edit</button>
    <button class="btn btn-sm btn-danger" onclick="deleteTask(${t.id})">Delete</button>
</td>
        `;
        tbody.appendChild(tr);
    });
}

function renderUpcomingTasks(tasks) {
    const list = document.getElementById("upcomingTasksList");
    if (!list) return;
    
    list.innerHTML = "";

    // Sort by deadline and filter out overdue tasks
    const sorted = tasks
        .filter(t => !isOverdue(t.deadline))
        .sort((a, b) => new Date(a.deadline) - new Date(b.deadline))
        .slice(0, 5);

    if (sorted.length === 0) {
        list.innerHTML = '<li class="text-secondary">No upcoming tasks. Great job!</li>';
        return;
    }

    sorted.forEach(t => {
        const li = document.createElement("li");
        li.innerHTML = `
            <span><strong>${escapeHtml(t.subject)}:</strong> ${escapeHtml(t.task)}</span>
            <span class="text-secondary small">${formatDate(t.deadline)}</span>
        `;
        list.appendChild(li);
    });
}

async function deleteTask(id) {
    if(!confirm("Are you sure you want to delete this task?")) return;
    
    try {
        const response = await fetch(`/delete_task/${id}`, { method: "DELETE" });
        if (response.ok) {
            showToast("Task deleted successfully");
            await loadTasks();
            await loadDashboardStats();
        } else {
            const data = await response.json();
            showToast(data.error || "Failed to delete task", "error");
        }
    } catch (e) {
        console.error("Error deleting task:", e);
        showToast("Error deleting task", "error");
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
async function editTask(id) {
    const newTask = prompt("Enter updated task:");
    if (!newTask) return;

    try {
        const response = await fetch(`/update_task/${id}`, {
            method: "PUT",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ task: newTask })
        });

        if (response.ok) {
            showToast("Task updated!");
            await loadTasks();
        } else {
            showToast("Failed to update task", "error");
        }
    } catch (e) {
        console.error("Error updating task:", e);
        showToast("Error updating task", "error");
    }
}

// ---------------- GRADES ---------------- //

function addGradeRow() {
    const container = document.getElementById("gradeEntries");
    const row = document.createElement("div");
    row.className = "grade-entry-row";
    row.innerHTML = `
        <input type="text" placeholder="Activity (e.g. Quiz 2)" class="grade-activity">
        <input type="number" placeholder="Score %" class="grade-score" min="0" max="100" step="0.1">
        <input type="number" placeholder="Weight %" class="grade-weight" min="0" max="100" step="0.1">
        <button class="btn btn-sm btn-danger" onclick="this.parentElement.remove()">×</button>
    `;
    container.appendChild(row);
}

function handleCalculateGrade() {
    const rows = document.querySelectorAll('.grade-entry-row');
    let totalScore = 0;
    let totalWeight = 0;
    let validEntries = 0;
    let activities = [];

    rows.forEach(row => {
        const activity = row.querySelector('.grade-activity').value.trim();
        const score = parseFloat(row.querySelector('.grade-score').value);
        const weight = parseFloat(row.querySelector('.grade-weight').value);

        if (!isNaN(score) && !isNaN(weight) && weight > 0) {
            totalScore += (score * weight);
            totalWeight += weight;
            validEntries++;
            activities.push({activity: activity || 'Unnamed', score, weight});
        }
    });

    if (validEntries === 0) {
        showToast("Please enter valid scores and weights.", "error");
        return;
    }

    if (totalWeight > 100) {
        showToast("Warning: Total weight exceeds 100%", "error");
    }

    const finalGrade = (totalScore / totalWeight).toFixed(2);
    currentGradeCalculation = {
        grade: finalGrade,
        activities: activities,
        totalWeight: totalWeight
    };
    
    const output = document.getElementById("gradeOutput");
    if (output) {
        output.innerHTML = `
            <div class="grade-result">Final Grade: <span class="grade-value">${finalGrade}%</span></div>
            <div class="grade-details">Based on ${validEntries} activities (${totalWeight.toFixed(1)}% total weight)</div>
        `;
    }
    
    return finalGrade;
}

async function saveCurrentGrade() {
    if (!currentGradeCalculation) {
        showToast("Please calculate a grade first", "error");
        return;
    }

    try {
        const response = await fetch("/save_grade", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                grade: currentGradeCalculation.grade,
                date: new Date().toISOString().split('T')[0],
                details: currentGradeCalculation.activities
            })
        });
        
        if (response.ok) {
            showToast("Grade saved successfully!");
            await loadGrades();
            await loadDashboardStats();
        } else {
            const data = await response.json();
            showToast(data.error || "Failed to save grade", "error");
        }
    } catch (e) {
        console.error("Error saving grade:", e);
        showToast("Error saving grade", "error");
    }
}

async function loadGrades() {
    try {
        const res = await fetch("/get_grades");
        if (!res.ok) throw new Error('Failed to fetch grades');
        
        const grades = await res.json();
        const list = document.getElementById("gradeHistoryList");
        
        if (!list) return;
        
        if (grades.length === 0) {
            list.innerHTML = '<p class="text-secondary">No saved grades yet. Calculate and save your first grade!</p>';
            return;
        }

        list.innerHTML = grades.slice().reverse().slice(0, 10).map((g, index) => `
            <div class="grade-history-item">
                <div class="grade-info">
                    <strong class="grade-score-display">${g.grade}%</strong>
                    <span class="text-secondary">${formatDate(g.date)}</span>
                </div>
                <button class="btn btn-sm btn-secondary" onclick="editGrade(${grades.length - 1 - index})">Edit</button>
<button class="btn btn-sm btn-danger" onclick="deleteGrade(${grades.length - 1 - index})">Delete</button>
            </div>
        `).join("");
    } catch (e) {
        console.error("Error loading grades:", e);
        showToast("Failed to load grades", "error");
    }
}

async function deleteGrade(index) {
    if (!confirm('Delete this grade record?')) return;
    
    try {
        const res = await fetch(`/delete_grade/${index}`, { method: 'DELETE' });
        if (res.ok) {
            showToast('Grade deleted');
            await loadGrades();
            await loadDashboardStats();
        }
    } catch (e) {
        console.error('Error deleting grade:', e);
        showToast('Failed to delete grade', 'error');
    }
}

async function editGrade(index) {
    const newGrade = prompt("Enter new grade:");
    if (!newGrade) return;

    try {
        const res = await fetch(`/update_grade/${index}`, {
            method: "PUT",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ grade: newGrade })
        });

        if (res.ok) {
            showToast("Grade updated!");
            await loadGrades();
        } else {
            showToast("Failed to update grade", "error");
        }
    } catch (e) {
        console.error("Error updating grade:", e);
    }
}

// ---------------- QUIZZES ---------------- //

async function loadSubjects() {
    try {
        const res = await fetch('/get_subjects');
        if (!res.ok) throw new Error('Failed to load subjects');
        
        const subjects = await res.json();
        const select = document.getElementById('quizSubjectSelect');
        if (!select) return;
        
        select.innerHTML = '<option value="">-- Select Subject --</option>' +
            subjects.map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('');
    } catch (e) {
        console.error('Error loading subjects:', e);
    }
}

async function loadTopics() {
    const subject = document.getElementById('quizSubjectSelect').value;
    const topicSelect = document.getElementById('quizTopicSelect');
    
    if (!subject) {
        topicSelect.disabled = true;
        topicSelect.innerHTML = '<option value="">-- First Select Subject --</option>';
        return;
    }
    
    try {
        const res = await fetch(`/get_topics/${encodeURIComponent(subject)}`);
        if (!res.ok) throw new Error('Failed to load topics');
        
        const topics = await res.json();
        topicSelect.innerHTML = '<option value="">-- Select Topic --</option>' +
            topics.map(t => `<option value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join('');
        topicSelect.disabled = false;
    } catch (e) {
        console.error('Error loading topics:', e);
        topicSelect.innerHTML = '<option value="">Error loading topics</option>';
    }
}

async function handleGenerateQuiz() {
    const subject = document.getElementById("quizSubjectSelect").value;
    const topic = document.getElementById("quizTopicSelect").value;
    const count = document.getElementById("quizCountInput").value;

    if (!subject && !topic) {
    showToast("Tip: Select a subject for focused quiz or leave blank for mixed quiz.", "success");
}
    try {
        const response = await fetch("/generate_quiz", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({subject, topic, count})
        });

        const data = await response.json();
        if (!response.ok || data.error) {
            showToast(data.error || "Failed to generate quiz", "error");
            return;
        }

        currentQuizData = data.questions;
        userAnswers = {};
        
        // Update quiz title
        const titleEl = document.getElementById("quizTitle");
        const subtitleEl = document.getElementById("quizSubtitle");
        if (titleEl) titleEl.innerText = `${data.subject} Quiz`;
        if (subtitleEl) subtitleEl.innerText = `${data.topic} • ${currentQuizData.length} questions`;
        
        renderQuiz();
        startQuizTimer();
    } catch (e) {
        console.error("Error generating quiz:", e);
        showToast("Error generating quiz", "error");
    }
}

function renderQuiz() {
    const container = document.getElementById("quizContainer");
    const questionsArea = document.getElementById("quizQuestions");
    const progressArea = document.getElementById("quizProgress");
    
    if (container) container.classList.remove('hidden');
    if (questionsArea) questionsArea.innerHTML = "";
    if (progressArea) progressArea.innerHTML = "";
    
    const resultEl = document.getElementById("quizResult");
    if (resultEl) resultEl.innerText = "";
    
    const submitBtn = document.getElementById("submitQuizBtn");
    if (submitBtn) submitBtn.disabled = false;

    currentQuizData.forEach((q, qIndex) => {
        // Progress indicator
        const progressDot = document.createElement("div");
        progressDot.className = "progress-dot";
        progressDot.id = `progress-${qIndex}`;
        progressDot.title = `Question ${qIndex + 1}`;
        if (progressArea) progressArea.appendChild(progressDot);

        // Question container
        const div = document.createElement("div");
        div.className = "quiz-question";
        div.id = `question-${qIndex}`;
        div.innerHTML = `<p class="question-text">${qIndex + 1}. ${escapeHtml(q.question)}</p>`;
        
        const optionsContainer = document.createElement("div");
        optionsContainer.className = "options-container";
        
        q.options.forEach(opt => {
            const optDiv = document.createElement("div");
            optDiv.className = "quiz-option";
            optDiv.innerText = opt;
            optDiv.onclick = () => selectOption(qIndex, opt, optDiv);
            optDiv.style.pointerEvents = "auto";
            optionsContainer.appendChild(optDiv);
        });
        
        div.appendChild(optionsContainer);
        if (questionsArea) questionsArea.appendChild(div);
    });
}

function selectOption(qIndex, option, element) {
    userAnswers[qIndex] = option;
    
    // Update progress
    const progressDot = document.getElementById(`progress-${qIndex}`);
    if (progressDot) progressDot.classList.add('answered');
    
    // Highlight UI
    const siblings = element.parentElement.querySelectorAll('.quiz-option');
    siblings.forEach(s => s.classList.remove('selected'));
    element.classList.add('selected');
    
    // Check if all answered
    if (Object.keys(userAnswers).length === currentQuizData.length) {
        showToast("All questions answered! Ready to submit.", "success");
    }
}

function startQuizTimer() {
    quizStartTime = Date.now();
    const timerEl = document.getElementById("quizTimer");
    
    if (quizTimerInterval) clearInterval(quizTimerInterval);
    
    quizTimerInterval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - quizStartTime) / 1000);
        const minutes = Math.floor(elapsed / 60).toString().padStart(2, '0');
        const seconds = (elapsed % 60).toString().padStart(2, '0');
        if (timerEl) timerEl.innerText = `${minutes}:${seconds}`;
    }, 1000);
}

function stopQuizTimer() {
    if (quizTimerInterval) {
        clearInterval(quizTimerInterval);
        quizTimerInterval = null;
    }
}

function handleSubmitQuiz() {
    if (Object.keys(userAnswers).length < currentQuizData.length) {
        const unanswered = currentQuizData.length - Object.keys(userAnswers).length;
        if (!confirm(`You have ${unanswered} unanswered question(s). Submit anyway?`)) {
            return;
        }
    }

    stopQuizTimer();
    
    let score = 0;
    const results = [];
    
    currentQuizData.forEach((q, index) => {
        const userAnswer = userAnswers[index];
        const isCorrect = userAnswer === q.answer;
        if (isCorrect) score++;
        
        results.push({
            question: q.question,
            userAnswer: userAnswer || 'No answer',
            correctAnswer: q.answer,
            isCorrect: isCorrect
        });
        
        // Visual feedback
        const questionEl = document.getElementById(`question-${index}`);
        if (questionEl) {
            const options = questionEl.querySelectorAll('.quiz-option');
            options.forEach(opt => {
                if (opt.innerText === q.answer) {
                    opt.classList.add('correct');
                } else if (opt.innerText === userAnswer && !isCorrect) {
                    opt.classList.add('incorrect');
                }
                opt.onclick = null; // Disable clicking
            });
        }
    });

    const percent = (score / currentQuizData.length * 100).toFixed(0);
    const timeTaken = document.getElementById("quizTimer").innerText;
    
    const resultEl = document.getElementById("quizResult");
    if (resultEl) {
        let gradeClass = percent >= 80 ? 'excellent' : percent >= 60 ? 'good' : 'needs-improvement';
        resultEl.innerHTML = `
            <div class="quiz-result-container ${gradeClass}">
                <div class="quiz-score">${score} / ${currentQuizData.length}</div>
                <div class="quiz-percentage">${percent}%</div>
                <div class="quiz-time">Time: ${timeTaken}</div>
                <div class="quiz-message">${getGradeMessage(percent)}</div>
            </div>
        `;
    }
    
    const submitBtn = document.getElementById("submitQuizBtn");
    if (submitBtn) submitBtn.disabled = true;
    
    // Save quiz result as grade
    saveQuizResult(percent, score, currentQuizData.length);
}

function getGradeMessage(percent) {
    if (percent >= 90) return "Outstanding work! 🌟";
    if (percent >= 80) return "Great job! 🎉";
    if (percent >= 70) return "Good effort! 👍";
    if (percent >= 60) return "Keep practicing! 📚";
    return "Review and try again! 💪";
}

async function saveQuizResult(grade, score, total) {
    try {
        await fetch("/save_grade", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                grade: grade,
                date: new Date().toISOString().split('T')[0],
                details: {
                    type: 'quiz',
                    score: score,
                    total: total,
                    topic: document.getElementById("quizTopicSelect").value
                }
            })
        });
        await loadGrades();
        await loadDashboardStats();
    } catch (e) {
        console.error("Error saving quiz result:", e);
    }
}

function resetQuiz() {
    stopQuizTimer();
    const container = document.getElementById("quizContainer");
    if (container) container.classList.add('hidden');
    userAnswers = {};
    currentQuizData = [];
    
    // Reset timer display
    const timerEl = document.getElementById("quizTimer");
    if (timerEl) timerEl.innerText = "00:00";
}

// ---------------- DASHBOARD ---------------- //

async function loadDashboardStats() {
    try {
        const res = await fetch("/get_dashboard_stats");
        if (!res.ok) throw new Error('Failed to load stats');
        
        const stats = await res.json();
        
        const totalTasksEl = document.getElementById("totalTasksCount");
        const pendingEl = document.getElementById("pendingCount");
        const avgGradeEl = document.getElementById("avgGradeValue");
        
        if (totalTasksEl) totalTasksEl.innerText = stats.total_tasks || 0;
        if (pendingEl) pendingEl.innerText = stats.pending_tasks || 0;
        if (avgGradeEl) avgGradeEl.innerText = (stats.average_grade || 0) + "%";
    } catch (e) {
        console.error("Error loading dashboard stats:", e);
    }
}

async function addNewQuestion() {
    const subject = document.getElementById("newSubject").value.trim();
    const topic = document.getElementById("newTopic").value.trim();
    const question = document.getElementById("newQuestion").value.trim();

    const options = [
        document.getElementById("opt1").value.trim(),
        document.getElementById("opt2").value.trim(),
        document.getElementById("opt3").value.trim(),
        document.getElementById("opt4").value.trim()
    ];

    const answer = document.getElementById("correctAnswer").value.trim();

    if (!subject || !topic || !question || options.includes("") || !answer) {
        showToast("Please fill all fields", "error");
        return;
    }

    if (!options.includes(answer)) {
        showToast("Correct answer must match one of the options", "error");
        return;
    }

    try {
        const res = await fetch("/add_question", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                subject,
                topic,
                question,
                options,
                answer
            })
        });

        const data = await res.json();

        if (res.ok) {
            showToast("Question added!");
            
            // Clear form
            document.querySelectorAll('#newSubject, #newTopic, #newQuestion, #opt1, #opt2, #opt3, #opt4, #correctAnswer')
                .forEach(el => el.value = "");

            loadSubjects(); // refresh dropdown
        } else {
            showToast(data.error, "error");
        }

    } catch (e) {
        console.error(e);
        showToast("Error adding question", "error");
    }
}