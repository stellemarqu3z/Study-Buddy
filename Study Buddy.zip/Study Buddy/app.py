import flask
import json
import os
import random
from datetime import datetime

app = flask.Flask(__name__, 
    static_folder='static',
    template_folder='templates'
)

# File paths - all in root directory for simplicity
TASKS_FILE = "tasks.json"
QUIZ_FILE = "quizzes.json"
GRADES_FILE = "grades.json"

# Initialize files if not existing
def init_files():
    # Create files with proper initial data if they don't exist
    if not os.path.exists(TASKS_FILE):
        with open(TASKS_FILE, "w") as f:
            json.dump([], f)

    if not os.path.exists(GRADES_FILE):
        with open(GRADES_FILE, "w") as f:
            json.dump([], f)

    if not os.path.exists(QUIZ_FILE):
        sample_data = {
            "Algebra": {
                "Linear Equations": [
                    {
                        "question": "What is the solution to 2x + 3 = 7?",
                        "options": ["x=1", "x=2", "x=3", "x=4"],
                        "answer": "x=2"
                    },
                    {
                        "question": "Solve: x - 5 = 10",
                        "options": ["x=5", "x=10", "x=15", "x=20"],
                        "answer": "x=15"
                    },
                    {
                        "question": "Find x if 3x = 12.",
                        "options": ["3", "4", "5", "6"],
                        "answer": "4"
                    },
                    {
                        "question": "Solve for x: x/2 = 8",
                        "options": ["4", "8", "16", "32"],
                        "answer": "16"
                    }
                ],
                "Quadratic Equations": [
                    {
                        "question": "What is the standard form of a quadratic equation?",
                        "options": ["ax + b = 0", "ax² + bx + c = 0", "x + y = 0", "a/x + b = 0"],
                        "answer": "ax² + bx + c = 0"
                    },
                    {
                        "question": "Solve: x² = 16",
                        "options": ["x=4", "x=-4", "x=±4", "x=8"],
                        "answer": "x=±4"
                    }
                ]
            },
            "Science": {
                "Biology": [
                    {
                        "question": "What is the powerhouse of the cell?",
                        "options": ["Nucleus", "Mitochondria", "Ribosome", "Golgi Body"],
                        "answer": "Mitochondria"
                    },
                    {
                        "question": "Which organ is responsible for pumping blood?",
                        "options": ["Liver", "Lungs", "Heart", "Kidneys"],
                        "answer": "Heart"
                    },
                    {
                        "question": "What is the basic unit of life?",
                        "options": ["Atom", "Cell", "Molecule", "Tissue"],
                        "answer": "Cell"
                    }
                ],
                "Chemistry": [
                    {
                        "question": "What is the chemical symbol for water?",
                        "options": ["H2O", "CO2", "O2", "NaCl"],
                        "answer": "H2O"
                    },
                    {
                        "question": "How many protons does carbon have?",
                        "options": ["4", "6", "8", "12"],
                        "answer": "6"
                    }
                ]
            },
            "History": {
                "World War II": [
                    {
                        "question": "In what year did World War II end?",
                        "options": ["1943", "1944", "1945", "1946"],
                        "answer": "1945"
                    },
                    {
                        "question": "Who was the British Prime Minister during most of WWII?",
                        "options": ["Neville Chamberlain", "Winston Churchill", "Clement Attlee", "Anthony Eden"],
                        "answer": "Winston Churchill"
                    }
                ]
            }
        }
        with open(QUIZ_FILE, "w") as f:
            json.dump(sample_data, f, indent=4)

init_files()

@app.route("/")
def home():
    return flask.render_template("index.html")

# ---------------- TASKS ---------------- #

@app.route("/add_task", methods=["POST"])
def add_task():
    try:
        data = flask.request.json
        if not data or 'subject' not in data or 'task' not in data or 'deadline' not in data:
            return flask.jsonify({"error": "Missing required fields"}), 400
        
        with open(TASKS_FILE, "r") as f:
            tasks = json.load(f)
        
        # Assign a unique ID
        new_id = max([t.get("id", 0) for t in tasks] + [0]) + 1
        data["id"] = new_id
        data["created_at"] = datetime.now().isoformat()
        tasks.append(data)

        with open(TASKS_FILE, "w") as f:
            json.dump(tasks, f, indent=4)

        return flask.jsonify({"message": "Task added!", "task": data}), 201
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

@app.route("/get_tasks")
def get_tasks():
    try:
        with open(TASKS_FILE, "r") as f:
            tasks = json.load(f)
        return flask.jsonify(tasks)
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

@app.route("/delete_task/<int:task_id>", methods=["DELETE"])
def delete_task(task_id):
    try:
        with open(TASKS_FILE, "r") as f:
            tasks = json.load(f)
        
        original_len = len(tasks)
        tasks = [t for t in tasks if t.get("id") != task_id]
        
        if len(tasks) == original_len:
            return flask.jsonify({"error": "Task not found"}), 404

        with open(TASKS_FILE, "w") as f:
            json.dump(tasks, f, indent=4)

        return flask.jsonify({"message": "Task deleted!"})
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

@app.route("/update_task/<int:task_id>", methods=["PUT"])
def update_task(task_id):
    try:
        data = flask.request.json
        with open(TASKS_FILE, "r") as f:
            tasks = json.load(f)
        
        task_found = False
        for task in tasks:
            if task.get("id") == task_id:
                task.update(data)
                task_found = True
                break
        
        if not task_found:
            return flask.jsonify({"error": "Task not found"}), 404

        with open(TASKS_FILE, "w") as f:
            json.dump(tasks, f, indent=4)

        return flask.jsonify({"message": "Task updated!"})
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

# ---------------- GRADES ---------------- #

@app.route("/save_grade", methods=["POST"])
def save_grade():
    try:
        data = flask.request.json
        if not data or 'grade' not in data:
            return flask.jsonify({"error": "Grade value required"}), 400
            
        with open(GRADES_FILE, "r") as f:
            grades = json.load(f)
        
        grade_entry = {
            "grade": data.get("grade"),
            "date": data.get("date", datetime.now().strftime("%Y-%m-%d")),
            "timestamp": datetime.now().isoformat(),
            "details": data.get("details", {})
        }
        grades.append(grade_entry)

        with open(GRADES_FILE, "w") as f:
            json.dump(grades, f, indent=4)

        return flask.jsonify({"message": "Grade saved!", "grade": grade_entry}), 201
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

@app.route("/get_grades")
def get_grades():
    try:
        if os.path.exists(GRADES_FILE):
            with open(GRADES_FILE, "r") as f:
                return flask.jsonify(json.load(f))
        return flask.jsonify([])
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

@app.route("/delete_grade/<int:index>", methods=["DELETE"])
def delete_grade(index):
    try:
        with open(GRADES_FILE, "r") as f:
            grades = json.load(f)
        
        if 0 <= index < len(grades):
            grades.pop(index)
            with open(GRADES_FILE, "w") as f:
                json.dump(grades, f, indent=4)
            return flask.jsonify({"message": "Grade deleted!"})
        return flask.jsonify({"error": "Invalid index"}), 400
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500
    
@app.route("/update_grade/<int:index>", methods=["PUT"])
def update_grade(index):
    try:
        data = flask.request.json

        with open(GRADES_FILE, "r") as f:
            grades = json.load(f)

        if 0 <= index < len(grades):
            grades[index].update(data)

            with open(GRADES_FILE, "w") as f:
                json.dump(grades, f, indent=4)

            return flask.jsonify({"message": "Grade updated!"})

        return flask.jsonify({"error": "Invalid index"}), 400

    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

# ---------------- QUIZ ---------------- #

@app.route("/get_subjects")
def get_subjects():
    try:
        with open(QUIZ_FILE, "r") as f:
            quizzes = json.load(f)
        return flask.jsonify(list(quizzes.keys()))
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

@app.route("/get_topics/<subject>")
def get_topics(subject):
    try:
        with open(QUIZ_FILE, "r") as f:
            quizzes = json.load(f)
        if subject in quizzes:
            return flask.jsonify(list(quizzes[subject].keys()))
        return flask.jsonify({"error": "Subject not found"}), 404
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

@app.route("/generate_quiz", methods=["POST"])
def generate_quiz():
    try:
        data = flask.request.json
        subject = data.get("subject")
        topic = data.get("topic")
        count = int(data.get("count", 5))

        if not subject or not topic:
            return flask.jsonify({"error": "Subject and topic required"}), 400

        with open(QUIZ_FILE, "r") as f:
            quizzes = json.load(f)

        if subject not in quizzes or topic not in quizzes[subject]:
            return flask.jsonify({"error": "Quiz subject/topic not found"}), 404
            
        questions = quizzes[subject][topic]
        if not questions:
            return flask.jsonify({"error": "No questions available for this topic"}), 404
            
        selected = random.sample(questions, min(count, len(questions)))
        
        # Add IDs to questions for tracking
        for i, q in enumerate(selected):
            q['id'] = i
            
        return flask.jsonify({
            "subject": subject,
            "topic": topic,
            "questions": selected,
            "total_available": len(questions)
        })
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

# ---------------- DASHBOARD STATS ---------------- #

@app.route("/get_dashboard_stats")
def get_dashboard_stats():
    try:
        # Get tasks stats
        with open(TASKS_FILE, "r") as f:
            tasks = json.load(f)
        
        total_tasks = len(tasks)
        # Count pending tasks (due date >= today)
        today = datetime.now().date()
        pending_tasks = len([t for t in tasks if datetime.fromisoformat(t.get('deadline', '2000-01-01')).date() >= today])
        
        # Get grades stats
        with open(GRADES_FILE, "r") as f:
            grades = json.load(f)
        
        avg_grade = 0
        if grades:
            avg_grade = sum(float(g.get('grade', 0)) for g in grades) / len(grades)
        
        return flask.jsonify({
            "total_tasks": total_tasks,
            "pending_tasks": pending_tasks,
            "average_grade": round(avg_grade, 1),
            "total_grades": len(grades)
        })
    except Exception as e:
        return flask.jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=8000)
    