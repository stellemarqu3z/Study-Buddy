from flask import Flask, render_template, request, jsonify
import json
import os
import random

app = Flask(__name__)

TASKS_FILE = "tasks.json"
QUIZ_FILE = "quizzes.json"

# Initialize files if not existing
def init_files():
    if not os.path.exists(TASKS_FILE):
        with open(TASKS_FILE, "w") as f:
            json.dump([], f)

    if not os.path.exists(QUIZ_FILE):
        sample_data = {
            "Algebra": {
                "Linear Equations": [
                    {
                        "question": "What is the solution to 2x + 3 = 7?",
                        "options": ["x=1", "x=2", "x=3", "x=4"],
                        "answer": "x=2"
                    },
                    {
                        "question": "Solve: x - 5 = 10",
                        "options": ["x=5", "x=10", "x=15", "x=20"],
                        "answer": "x=15"
                    }
                ]
            }
        }
        with open(QUIZ_FILE, "w") as f:
            json.dump(sample_data, f, indent=4)

init_files()

@app.route("/")
def home():
    return render_template("index.html")

# ---------------- TASKS ---------------- #

@app.route("/add_task", methods=["POST"])
def add_task():
    data = request.json

    with open(TASKS_FILE, "r") as f:
        tasks = json.load(f)

    tasks.append(data)

    with open(TASKS_FILE, "w") as f:
        json.dump(tasks, f, indent=4)

    return jsonify({"message": "Task added!"})

@app.route("/get_tasks")
def get_tasks():
    with open(TASKS_FILE, "r") as f:
        tasks = json.load(f)
    return jsonify(tasks)

# ---------------- GRADES ---------------- #

@app.route("/calculate_grade", methods=["POST"])
def calculate_grade():
    data = request.json

    total_weighted = 0
    total_weight = 0

    for activity in data["activities"]:
        percentage = (activity["score"] / activity["max_score"]) * 100
        total_weighted += percentage * activity["weight"]
        total_weight += activity["weight"]

    final_grade = total_weighted / total_weight

    return jsonify({"final_grade": round(final_grade, 2)})

# ---------------- QUIZ ---------------- #

@app.route("/generate_quiz", methods=["POST"])
def generate_quiz():
    data = request.json
    subject = data["subject"]
    topic = data["topic"]
    count = int(data["count"])

    with open(QUIZ_FILE, "r") as f:
        quizzes = json.load(f)

    try:
        questions = quizzes[subject][topic]
        selected = random.sample(questions, min(count, len(questions)))
        return jsonify(selected)
    except:
        return jsonify({"error": "Quiz not found"}), 404

if __name__ == "__main__":
    app.run(debug=True)