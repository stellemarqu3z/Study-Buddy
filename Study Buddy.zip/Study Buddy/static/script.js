function showSection(id) {
    document.querySelectorAll('.section').forEach(sec => {
        sec.classList.remove('active');
    });
    document.getElementById(id).classList.add('active');
}

window.onload = function() {
    document.getElementById("todayDate").innerText =
        new Date().toDateString();
};

async function addTask() {
    const subject = document.getElementById("subject").value;
    const task = document.getElementById("task").value;
    const deadline = document.getElementById("deadline").value;

    await fetch("/add_task", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({subject, task, deadline})
    });

    alert("Task added!");
}

async function loadTasks() {
    const response = await fetch("/get_tasks");
    const tasks = await response.json();

    const list = document.getElementById("taskList");
    list.innerHTML = "";

    tasks.forEach(t => {
        const li = document.createElement("li");
        li.textContent = `${t.subject} - ${t.task} (Due: ${t.deadline})`;
        list.appendChild(li);
    });
}

async function calculateGrade() {
    const sample = {
        activities: [
            {score: 85, max_score: 100, weight: 0.5},
            {score: 90, max_score: 100, weight: 0.5}
        ]
    };

    const response = await fetch("/calculate_grade", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(sample)
    });

    const result = await response.json();
    document.getElementById("gradeResult").innerText =
        "Final Grade: " + result.final_grade + "%";
}

async function generateQuiz() {
    const subject = document.getElementById("quizSubject").value;
    const topic = document.getElementById("quizTopic").value;
    const count = document.getElementById("quizCount").value;

    const response = await fetch("/generate_quiz", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({subject, topic, count})
    });

    const data = await response.json();
    const area = document.getElementById("quizArea");
    area.innerHTML = "";

    if (data.error) {
        area.innerText = data.error;
        return;
    }

    data.forEach((q, index) => {
        const div = document.createElement("div");
        div.innerHTML = `<b>Q${index+1}:</b> ${q.question}<br>` +
            q.options.map(opt => `<input type="radio"> ${opt}<br>`).join("");
        area.appendChild(div);
    });